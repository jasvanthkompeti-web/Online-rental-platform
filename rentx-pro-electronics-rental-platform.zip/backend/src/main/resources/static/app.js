const grid=document.getElementById('grid'),search=document.getElementById('search');
function cart(){return JSON.parse(localStorage.getItem('rentxCart')||'[]')}
function updateCount(){let n=cart().reduce((s,x)=>s+x.quantity,0);let e=document.getElementById('cartCount');if(e)e.textContent=n}
async function load(url='/api/products'){
 const r=await fetch(url);const ps=await r.json();
 grid.innerHTML=ps.map(p=>`<article class="card">
 <img src="${p.imageUrl}" alt="${p.name}">
 <div class="card-body"><span class="pill">${p.category}</span><h3>${p.name}</h3><p>${p.brand}</p>
 <p class="desc">${p.description}</p><div class="card-bottom"><strong>₹${p.pricePerDay}/day</strong>
 <button class="btn small" ${p.available?'':'disabled'} onclick='add(${JSON.stringify(p)})'>${p.available?'Add to Cart':'Unavailable'}</button></div>
 </div></article>`).join('')||'<p>No products found.</p>'; updateCount()
}
function add(p){let c=cart(),x=c.find(i=>i.id===p.id);if(x)x.quantity++;else c.push({id:p.id,name:p.name,brand:p.brand,price:p.pricePerDay,deposit:p.securityDeposit,image:p.imageUrl,quantity:1});localStorage.setItem('rentxCart',JSON.stringify(c));updateCount();alert(p.name+' added to cart')}
function category(c){load('/api/products/category/'+encodeURIComponent(c))}
search?.addEventListener('input',()=>load(search.value?'/api/products/search?q='+encodeURIComponent(search.value):'/api/products'));
load();updateCount();
